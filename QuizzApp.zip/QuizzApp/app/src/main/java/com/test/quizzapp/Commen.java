package com.test.quizzapp;

public class Commen {
    public static String login;
    public static String password;
}